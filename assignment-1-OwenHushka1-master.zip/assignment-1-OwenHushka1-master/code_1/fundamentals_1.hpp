#ifndef READFILE_H__
#define READFILE_H__

#include <string>
#include <iostream>
#include <fstream>

using namespace std;

// TODO add detailed explanation on what the function should do
int addToArrayAsc(float sortedArray[], int numElements, float newValue); 
//function which takes in a sorted array, the number of elements in the array and a value to insert into the array 
//and inserts the new value into the correct position so that the array is in ascending order. 

#endif // READFILE_H__